export const instanceConfig = {
  min: 1,
  max: 16,
  step: 1,
  defaultValue: 1,
  value: 1
};
