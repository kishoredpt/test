const constants = {
  minikubeIp: '192.168.99.100'
};

export default constants;
