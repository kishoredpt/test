## Kr8ssword Puzzle Kubernetes CI / CD , Microservices Example

# setup
From the root directory of the repository, use 'npm run part1' to setup the minikube cluster.

### Building
    Use or review <root>/scripts/kr8sswordz-pages.sh for build/deployment steps 
    
## Load application
Run 'minikube service kr8sswordz'

or

Change MINIKUBEIP to your minikube ip and load the application below

    http://kr8sswordz.MINIKUBEIP.xip.io/ 
